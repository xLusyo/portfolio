# Codex implementation prompt

Implement a responsive personal portfolio using the attached `Portfolio_Mockup_Export.zip` as the approved design reference. Unzip it and read `README.md`, `DESIGN_SPEC.md`, `index.html`, `style.css`, and `app.js` before making changes. The included source is the visual source of truth; `assets/reference.png` is the original inspiration image.

Build the website in the current repository. Inspect its existing framework and conventions first, and use the existing stack. If the repository is empty, the supplied HTML, CSS, and JavaScript are a suitable starting point. Make the implementation, rather than only describing a plan.

Preserve the approved visual direction: near-black background, charcoal rounded panels, a light neutral outer canvas, generous spacing, muted grey secondary text, restrained accents, and clean sans-serif typography. Keep the composition close to the supplied mockup rather than redesigning it.

Desktop requirements:
- Keep the left profile column fixed in place while the right content column scrolls independently. Use a full-height grid with a non-scrolling left column; avoid overlapping fixed elements.
- Include the profile photo, name, role, professional information, website/email, and social links in the left column.
- Place an outlined “Download Resume” CTA and a filled “Contact me” CTA in the profile panel.
- Include these right-column sections in order: About me / professional summary, Work Experience, Recent Projects, and Tech Stack & Tools.
- Keep the right-column section navigation sticky, highlight the active section, and support smooth anchor navigation.

Mobile requirements:
- At approximately 760px and below, switch to one column with the photo and profile first, followed by all four content sections.
- Use a single scroll container. Keep compact section navigation sticky and a bottom contact action accessible without covering the final content.
- Stack project cards, use a two-column tools grid, and prevent horizontal overflow. Ensure comfortable touch targets and readable text.

Functionality and content:
- Keep project cards interactive with accessible detail dialogs or equivalent project detail views.
- Wire the résumé download to a supplied résumé PDF when available. Until then, clearly identify the existing download as a sample.
- Use supplied contact details when available. The current form only prepares an email draft; do not claim it sends messages or add a backend without a requirement.
- Keep profile, experience, project, tool, and contact data easy to update from one content module or data file.
- Charlie Foley, the reference portrait, employer history, sample projects, and contact links are demonstration content. Use my actual details only if I provide them. Do not invent personal claims or publish the demonstration profile as my identity.
- The Desktop/Mobile switch and “design concept” toolbar are mockup presentation controls. Keep them available for review; make it easy to omit them from a final production page.

Quality checks:
- Use semantic markup, keyboard-accessible controls and dialogs, visible focus states, descriptive image text, adequate contrast, and reduced-motion support.
- Verify desktop at 1440×900 and 1280×800, and mobile at 390×844 and 375×812. Confirm independent desktop scrolling, mobile navigation/contact positioning, no overflow, working downloads, and modal keyboard behavior. Capture desktop and mobile screenshots if the environment supports it; state any verification limits.
- Run the repository’s relevant checks and provide startup instructions and a concise change summary. Do not deploy or publish unless I ask.
