# Approved design specification

## Visual direction

Dark, minimal portfolio inspired by the supplied reference. The external canvas is warm light grey (`#e9e9e6`), the portfolio shell is almost black (`#030303`), and section panels are charcoal (`#121212`). Primary text is off-white (`#f1f1ef`); supporting text uses muted greys. Accent colour is limited to soft sage availability details and restrained project artwork.

Typography: DM Sans with Arial/sans-serif fallback. The source stylesheet contains the exact sizes, spacing, borders, and responsive rules. Preserve those values as the initial implementation baseline.

## Desktop composition

- Light outer canvas and a compact design-preview toolbar.
- Portfolio shell: max-width 1420px, 35px outer radius, 12px padding and grid gap.
- Left profile column: normally 330px, with a portrait card above the information/action card. Its position stays unchanged while the right column scrolls.
- Right column: flexible width, independent vertical scroll, sticky section navigation, and rounded content panels.
- Section order: About, Work Experience, Recent Projects, Tech Stack & Tools.
- Recent projects: two columns. Toolkit: four columns, adapting to two on narrower screens.

## Mobile composition

- Main layout breakpoint: 760px.
- Single scrolling column. Portrait, profile information, and CTAs precede the content sections.
- Sticky section menu and floating bottom contact bar.
- Project cards become one column. Tool cards use two columns.
- The Desktop/Mobile toolbar switch displays a 390px iframe for mobile review. This control is presentation chrome, separate from the actual responsive layout.

## Interaction inventory

- Section links with active-section highlighting.
- Resume button downloads a clearly labelled sample text résumé.
- Contact buttons open a native dialog with name, email, and message fields; submitting prepares a mailto draft using a sample address.
- Project cards open detail dialogs with project artwork, idea, and scope.
- Social/website demo buttons provide a toast instead of navigating to unconfigured destinations.
- Native dialogs support Escape-to-close; close buttons and backdrop dismissal are included.

## Content boundary

The sample profile and reference portrait are demonstration material. The two project concepts and toolkit are illustrative. Replace them only with supplied real content, and preserve clear sample labels until that happens.

## Checks for the next implementation

Review small-height desktop layouts, touch-target sizes, contrast of small muted text, reduced-motion preferences, keyboard focus restoration, and the bottom contact bar's clearance. Browser screenshots were not captured during the initial implementation.
