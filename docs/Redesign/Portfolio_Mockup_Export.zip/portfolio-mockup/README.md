# Folio — Portfolio mockup export

This package contains the source of the approved desktop and mobile portfolio mockup, plus a ready-to-paste Codex prompt.

## Contents

- `index.html` — page structure and demonstration content.
- `style.css` — desktop/mobile layouts, components, and visual styling.
- `app.js` — preview controls, section highlighting, dialogs, sample résumé download, and email-draft preparation.
- `assets/reference.png` — original supplied design reference. The portrait is displayed through an SVG viewport into this image.
- `CODEX_PROMPT.md` — implementation prompt for Codex.
- `DESIGN_SPEC.md` — layout, styling, interaction, and content notes.

## Use with Codex

1. Unzip the package into your project, or attach the ZIP if your Codex environment accepts archives.
2. Copy the text under the heading in `CODEX_PROMPT.md` and paste it into Codex.
3. Supply your actual photo, résumé, profile information, project details, and contact links when you want to replace the sample content.

## Run the current mockup

From the extracted directory, run:

```bash
python3 -m http.server 8000
```

Open `http://localhost:8000`. Use the Desktop/Mobile switch at the top, or resize the browser. An HTTP server is recommended for the iframe-based mobile preview. No package installation or build is required. DM Sans is requested from Google Fonts; Arial/system sans-serif is the fallback when offline.

## Important implementation notes

The source is exported without changes to its current design. No hosting configuration, repository history, credentials, or deployment metadata is included.

The sample résumé downloads as plain text. The contact form opens an email draft addressed to `hello@example.com`; it does not send email. Social and website buttons show demonstration feedback. Project detail views are illustrative concepts. The reference portrait and employer history are not the user's personal profile.

Syntax, local asset references, section anchors, and hosting structure were checked during creation. Browser visual verification was unavailable in that environment. The attached prompt requests responsive and interaction checks in the receiving environment.
